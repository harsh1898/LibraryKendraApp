package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryKendraBookWishlistApplicationTests {

    @Test
    void contextLoads() {
    }

}
