package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.repository;

import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.model.WishlistData;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class WishlistUserRepoTest {

    @Autowired
    WishlistUserRepo wishlistUserRepo;

    private WishlistData wishlistData;

    @BeforeEach
    public void setUp() {
        wishlistData = new WishlistData();
        wishlistData.setTitle("Harry Potter");
        wishlistData.setAuthors("J.K. Rowling");
        wishlistData.setBook_type("Fiction");
        wishlistData.setLanguage("English");
        wishlistData.setSummary("Harry Potter is a series of fantasy novels written by British author J. K. Rowling.");
        wishlistData.setUsername("harsh@gmail.com");
    }
    @AfterEach
    public void tearDown() {
        wishlistUserRepo.deleteAll();
        wishlistData = null;
    }
    @Test
    void testSaveUserCredential() {
        wishlistUserRepo.save(wishlistData);
        List<WishlistData> saveWishlistData = wishlistUserRepo.findWishlistByUsername(wishlistData.getUsername());
        assertEquals("Harry Potter", saveWishlistData.get(0).getTitle());

    }

}