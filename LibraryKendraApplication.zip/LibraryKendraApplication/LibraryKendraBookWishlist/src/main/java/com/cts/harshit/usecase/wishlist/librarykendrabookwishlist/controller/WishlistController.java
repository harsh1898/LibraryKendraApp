package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.controller;


import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.exception.WishlistAlreadyExistsException;
import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.exception.WishlistNotFoundException;
import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.exception.WishlistUserNotCorrectException;
import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.model.WishlistData;
import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.service.WishlistBookService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/wishlist")
@SecurityRequirement(name = "bearerAuth")
@CrossOrigin(origins = "*")
public class WishlistController {


   private final  WishlistBookService wishlistBookService;

   @Autowired
    public WishlistController(WishlistBookService wishlistBookService){
    this.wishlistBookService=wishlistBookService;
   }
    @PostMapping("/addWishlist")
    public ResponseEntity<?> saveWishlistByUsername(@RequestBody WishlistData wishlistBook) throws WishlistAlreadyExistsException{
       try {
           return ResponseEntity.ok(wishlistBookService.saveWishlistByUsername(wishlistBook));
       }catch(WishlistAlreadyExistsException e){
           return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
       }
    }

    @GetMapping("/getWishlist/{username}")
    public ResponseEntity<?> getallWishlistByUsername(@PathVariable String username) throws WishlistNotFoundException , WishlistUserNotCorrectException {
       try {
           return ResponseEntity.ok(wishlistBookService.getallWishlistByUsername(username));
       } catch(WishlistNotFoundException e){
           return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
       } catch(WishlistUserNotCorrectException e){
           return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
       }

    }

    @DeleteMapping("/deleteWishlist/{id}")
    public ResponseEntity<?> deleteWishlist(@PathVariable int id){
        return ResponseEntity.ok(wishlistBookService.deleteWishlist(id));
    }

}
