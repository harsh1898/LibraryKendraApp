package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.exception;

public class WishlistNotFoundException extends RuntimeException{

    private String message;
    public WishlistNotFoundException(String message){

        super(message);
        this.message=message;
    }
}
