package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.exception;

public class WishlistAlreadyExistsException extends RuntimeException{

    private String message;

    public WishlistAlreadyExistsException(String message){
        super(message);
        this.message = message;
    }
}
