package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.service;


import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.exception.WishlistAlreadyExistsException;
import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.exception.WishlistNotFoundException;
import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.exception.WishlistUserNotCorrectException;
import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.model.WishlistData;
import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.repository.WishlistUserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class WishlistBookServiceImpl implements WishlistBookService {

    @Autowired
    private WishlistUserRepo wishlistUserRepo;

    public WishlistBookServiceImpl(WishlistUserRepo wishlistUserRepo) {
        this.wishlistUserRepo = wishlistUserRepo;
    }


    @Override
    public WishlistData saveWishlistByUsername(WishlistData wishlistData){
        List<WishlistData> data = wishlistUserRepo.findWishlistByUsername(wishlistData.getUsername());
        for (WishlistData existingData : data) {
            if ((existingData.getWork_id())==(wishlistData.getWork_id())) {
                throw new WishlistAlreadyExistsException("Already Added in your wishlist");
            }
        }
            return wishlistUserRepo.save(wishlistData);

    }

    @Override
    public List<WishlistData> getallWishlistByUsername(String username) throws WishlistNotFoundException {
        if(wishlistUserRepo.findWishlistByUsername(username)==null){
          throw new WishlistUserNotCorrectException("Name is not correct");
        }
        List<WishlistData> data = wishlistUserRepo.findWishlistByUsername(username);
        if(data.isEmpty()){
            throw new WishlistNotFoundException("Wishlist not found");
        }

        else {
            List<WishlistData> data1 = new ArrayList<>();
            data1.addAll(data);
            return data1;
        }
    }

@Override
    public String  deleteWishlist(int id){
       wishlistUserRepo.deleteById(id);
       return "Wishlist removed from your account";
}
}
