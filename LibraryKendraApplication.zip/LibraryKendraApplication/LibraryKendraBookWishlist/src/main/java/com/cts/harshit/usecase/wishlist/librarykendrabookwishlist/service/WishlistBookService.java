package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.service;

import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.model.WishlistData;
import org.w3c.dom.stylesheets.LinkStyle;

import java.util.List;

public interface WishlistBookService {

WishlistData saveWishlistByUsername(WishlistData wishlistData);

 List<WishlistData>  getallWishlistByUsername(String username);

 String  deleteWishlist(int id);


}
