package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.exception;

public class WishlistUserNotCorrectException extends RuntimeException{
    private String message;
    public WishlistUserNotCorrectException(String message){

        super(message);
        this.message=message;
    }
}
