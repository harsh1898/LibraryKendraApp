package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.repository;

import com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.model.WishlistData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface WishlistUserRepo extends JpaRepository<WishlistData,Integer> {

    @Query("select u from WishlistData u where u.username = :username ")
    List<WishlistData> findWishlistByUsername(String username);


}
