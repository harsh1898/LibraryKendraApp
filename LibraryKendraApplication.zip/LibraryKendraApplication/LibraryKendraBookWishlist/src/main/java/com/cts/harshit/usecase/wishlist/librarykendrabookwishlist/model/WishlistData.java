package com.cts.harshit.usecase.wishlist.librarykendrabookwishlist.model;


import jakarta.persistence.*;

@Entity
@Table(name="BookWishlistData")
public class WishlistData {


    @Id
    private int work_id;

    private String title;

    private String authors;

    private String book_type;

    private String language;

    @Column(columnDefinition = "TEXT")
    private String summary;

    private String cover_art_url;
    private String username;

    public WishlistData(int work_id, String title, String authors, String book_type, String language, String summary, String cover_art_url, String username) {
        this.work_id = work_id;
        this.title = title;
        this.authors = authors;
        this.book_type = book_type;
        this.language = language;
        this.summary = summary;
        this.cover_art_url = cover_art_url;
        this.username = username;
    }

    public WishlistData(){}

    public int getWork_id() {
        return work_id;
    }

    public void setWork_id(int work_id) {
        this.work_id = work_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public String getBook_type() {
        return book_type;
    }

    public void setBook_type(String book_type) {
        this.book_type = book_type;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getCover_art_url() {
        return cover_art_url;
    }

    public void setCover_art_url(String cover_art_url) {
        this.cover_art_url = cover_art_url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
