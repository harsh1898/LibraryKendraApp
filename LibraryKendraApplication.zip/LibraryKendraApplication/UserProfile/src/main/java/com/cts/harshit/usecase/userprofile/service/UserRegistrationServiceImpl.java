package com.cts.harshit.usecase.userprofile.service;

import com.cts.harshit.usecase.userprofile.exception.ContactNumberValidException;
import com.cts.harshit.usecase.userprofile.exception.EmailNotBlankException;
import com.cts.harshit.usecase.userprofile.exception.UserAlredayExistsException;
import com.cts.harshit.usecase.userprofile.exception.UserNotFoundException;
import com.cts.harshit.usecase.userprofile.model.UserRegistration;
import com.cts.harshit.usecase.userprofile.repository.UserRegistrationRepo;
import org.apache.kafka.clients.admin.NewTopic;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UserRegistrationServiceImpl implements UserRegistrationService{

    Logger logger = Logger.getLogger(UserRegistrationServiceImpl.class.getName());
    @Autowired
   private final UserRegistrationRepo userRegistrationRepo;
    @Autowired
    private NewTopic topic;

    @Autowired
    private KafkaTemplate<String,UserRegistration> kafkaTemplate;

    @Autowired
    public UserRegistrationServiceImpl(UserRegistrationRepo userRegistrationRepo,NewTopic topic, KafkaTemplate<String,UserRegistration>kafkaTemplate) {
        this.userRegistrationRepo = userRegistrationRepo;
        this.topic = topic;
        this.kafkaTemplate=kafkaTemplate;
    }


    @Override
    public UserRegistration saveUser(UserRegistration userRegistration) throws UserAlredayExistsException, EmailNotBlankException {

        UserRegistration user = userRegistrationRepo.findByEmail(userRegistration.getUsername());
        if(user!=null) {
           throw new UserAlredayExistsException("User Already Exists with this username");
        }
        if(userRegistration.getUsername().isBlank()){
            throw new EmailNotBlankException("Username can not be blank");
        }
        if(userRegistration.getUsername().equals("null")){
            throw new EmailNotBlankException("Username can not contain null as value");
        }
        if (userRegistration.getPassword().isBlank()){
            throw new EmailNotBlankException("Password can not be blank");
        }
        if(!userRegistration.getUsername().endsWith("@gmail.com")){
            throw new EmailNotBlankException("Username format is not correct. Should be in email format");
        }
        if((Long.toString(userRegistration.getContactnumber()).length())<=9){
            throw new ContactNumberValidException("Contact Number should contain at least 10 digits");
        }
        else{
            LocalDateTime dateTime = LocalDateTime.now();
            UserRegistration registerdata = userRegistrationRepo.save(userRegistration);
            Message<UserRegistration> message = MessageBuilder
                    .withPayload(userRegistration)
                    .setHeader(KafkaHeaders.TOPIC,topic.name())
                    .build();
            kafkaTemplate.send(message);
            logger.log(Level.INFO,"New User Created "+userRegistration+dateTime);
            return registerdata;
        }
    }

    @Override
    public UserRegistration getUser(String username) throws UserNotFoundException {
        LocalDateTime dateTime = LocalDateTime.now();

        logger.log(Level.INFO,"User Detail by their email"+username+dateTime);
        UserRegistration user = userRegistrationRepo.findByEmail(username);
        if(user != null) {
            return user;
        }else {
            throw new UserNotFoundException("User Not Found");
        }


    }
    @Override
    public UserRegistration updateUser(UserRegistration userRegistration, String username) throws UserNotFoundException , EmailNotBlankException {
        UserRegistration user = userRegistrationRepo.findByEmail(username);
        if(userRegistration.getUsername().isBlank()){
            throw new EmailNotBlankException("Username can not be blank");
        }
        if (userRegistration.getPassword().isBlank()){
            throw new EmailNotBlankException("Password can not be blank");
        }
        if(userRegistration.getUsername().equals("null")){
            throw new EmailNotBlankException("Username can not contain null as value");
        }
        if(user != null) {
            UserRegistration newuser = user;
            newuser.setUsername(userRegistration.getUsername());
            newuser.setFirstname(userRegistration.getFirstname());
            newuser.setLastname(userRegistration.getLastname());
            newuser.setContactnumber(userRegistration.getContactnumber());
            newuser.setPassword(userRegistration.getPassword());

            return userRegistrationRepo.save(newuser);
        }else {
            throw new UserNotFoundException("User Not Found");
        }



    }
    @Override
    public String deleteUser(String username)  throws UserNotFoundException{
        UserRegistration user = userRegistrationRepo.findByEmail(username);
        if (user != null) {
            userRegistrationRepo.deleteById(user.getRegistrationId());
            return "User Deleted";
        }else {
            throw new UserNotFoundException("User Not Found");

        }
    }

}
