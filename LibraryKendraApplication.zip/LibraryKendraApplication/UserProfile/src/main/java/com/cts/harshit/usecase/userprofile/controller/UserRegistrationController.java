package com.cts.harshit.usecase.userprofile.controller;

import com.cts.harshit.usecase.userprofile.exception.ContactNumberValidException;
import com.cts.harshit.usecase.userprofile.exception.EmailNotBlankException;
import com.cts.harshit.usecase.userprofile.exception.UserAlredayExistsException;
import com.cts.harshit.usecase.userprofile.exception.UserNotFoundException;
import com.cts.harshit.usecase.userprofile.model.UserRegistration;
import com.cts.harshit.usecase.userprofile.service.UserRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("libraryKendra/registration")
@CrossOrigin(origins = "*")
public class UserRegistrationController {


private final UserRegistrationService userRegistrationService;
@Autowired
    public UserRegistrationController(UserRegistrationService userRegistrationService)  {
        this.userRegistrationService = userRegistrationService;
    }

    @PostMapping("/userRegistration")
    public ResponseEntity<?> saveUser(@RequestBody UserRegistration userRegistration) throws UserAlredayExistsException , EmailNotBlankException, ContactNumberValidException {
        try {
            return ResponseEntity.ok(userRegistrationService.saveUser(userRegistration));
        } catch (UserAlredayExistsException | EmailNotBlankException | ContactNumberValidException e) {
           return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        }
    }
    @GetMapping("/getuser/{username}")
    public ResponseEntity<?> getUser(@PathVariable("username") String username) throws UserNotFoundException {
        try{
            return ResponseEntity.ok(userRegistrationService.getUser(username));
        }catch (UserNotFoundException e){
            throw new UserNotFoundException(e.getMessage());
        }



    }
    @PutMapping("/userUpdate/{username}")

    public ResponseEntity<?> updateUser(@RequestBody UserRegistration user, @PathVariable("username") String username) throws UserNotFoundException,EmailNotBlankException {
        try{
        return ResponseEntity.ok(userRegistrationService.updateUser(user, username));
    }catch (UserNotFoundException | EmailNotBlankException e){

            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
        }
    }

    @DeleteMapping("/userDelete/{username}")
    public ResponseEntity<?> deleteUser(@PathVariable("username") String username) throws UserNotFoundException{
    try {
        return ResponseEntity.ok(userRegistrationService.deleteUser(username));
    }catch (UserNotFoundException e){
        throw new UserNotFoundException(e.getMessage());

    }
    }


}
