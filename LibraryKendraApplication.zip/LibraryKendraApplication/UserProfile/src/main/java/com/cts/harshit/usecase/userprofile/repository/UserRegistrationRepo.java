package com.cts.harshit.usecase.userprofile.repository;

import com.cts.harshit.usecase.userprofile.model.UserRegistration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface UserRegistrationRepo extends JpaRepository<UserRegistration,Long> {

    @Query("select u from UserRegistration u where u.username = :username")
    UserRegistration findByEmail(String username);
}
