package com.cts.harshit.usecase.userprofile.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="user_registration")
public class UserRegistration {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(unique=true)
    private long registrationId;
    @NotNull(message = "Username can not contain null as value")
    @Email
    @NotBlank
    private String username;
    @NotNull(message="First Name can not be null")
    private String firstname;
    @NotNull(message="Last Name can not be null")
    private String lastname;
    @NotNull(message="Contact Number can not be null")
    private long contactnumber;
    @NotNull(message = "Password can not contain null as value")
    private String password;

    @Override
    public String toString() {
        return "UserRegistration{" +
                "registrationId=" + registrationId +
                ", username='" + username + '\'' +
                ", firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                ", contactnumber=" + contactnumber +
                ", password='" + password + '\'' +
                '}';
    }
}
