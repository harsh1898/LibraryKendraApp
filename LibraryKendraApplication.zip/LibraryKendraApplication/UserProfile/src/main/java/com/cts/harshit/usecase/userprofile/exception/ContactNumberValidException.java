package com.cts.harshit.usecase.userprofile.exception;

public class ContactNumberValidException extends RuntimeException{
    private String message;

    public ContactNumberValidException(String message){
        super(message);
        this.message = message;
    }

}
