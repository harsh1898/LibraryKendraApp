package com.cts.harshit.usecase.userprofile.service;


import com.cts.harshit.usecase.userprofile.model.UserRegistration;

public interface UserRegistrationService {

    UserRegistration saveUser(UserRegistration userRegistration);

    UserRegistration updateUser(UserRegistration userRegistration, String username);

    String deleteUser(String username);

    UserRegistration getUser(String username);


}
