package com.cts.harshit.usecase.userprofile.exception;

public class UserAlredayExistsException extends RuntimeException {
    private String message;
    public UserAlredayExistsException(String message) {
        super(message);
        this.message=message;

    }
    public UserAlredayExistsException() {}
}
