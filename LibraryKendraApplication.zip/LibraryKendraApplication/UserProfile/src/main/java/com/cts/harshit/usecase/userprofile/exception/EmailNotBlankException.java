package com.cts.harshit.usecase.userprofile.exception;

public class EmailNotBlankException extends RuntimeException{

    private String message;
    public EmailNotBlankException(String message) {
        super(message);
        this.message = message;
    }
}
