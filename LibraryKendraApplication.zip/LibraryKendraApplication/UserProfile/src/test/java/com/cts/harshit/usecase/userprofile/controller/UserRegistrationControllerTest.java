package com.cts.harshit.usecase.userprofile.controller;

import com.cts.harshit.usecase.userprofile.exception.GlobalExceptionHandler;
import com.cts.harshit.usecase.userprofile.model.UserRegistration;
import com.cts.harshit.usecase.userprofile.service.UserRegistrationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import java.util.ArrayList;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@ExtendWith(MockitoExtension.class)
class UserRegistrationControllerTest {

    @Mock
    UserRegistrationService userRegistrationService;

    @InjectMocks
    UserRegistrationController userRegistrationController;

    private UserRegistration userRegistration;

    private MockMvc mockMvc;

    private List<UserRegistration> userRegistrationList;

    @BeforeEach
    public void setUp(){
        mockMvc = MockMvcBuilders.standaloneSetup(userRegistrationController).setControllerAdvice(new GlobalExceptionHandler()).build();
        userRegistration = new UserRegistration();
        userRegistration.setUsername("test@gmail.com");
        userRegistration.setFirstname("firsttest");
        userRegistration.setLastname("lasttest");
        userRegistration.setContactnumber(879913409);
        userRegistration.setPassword("testPassword");
        userRegistrationList = new ArrayList<>();
        userRegistrationList.add(userRegistration);

    }
    @AfterEach
    public void tearDown(){
        userRegistration = null;
        userRegistrationList = null;
        mockMvc = null;
        userRegistrationService = null;
        userRegistrationController = null;
    }

    @Test
    void TestRegisterUser() throws Exception {
        when(userRegistrationService.saveUser(any())).thenReturn(userRegistration);
        mockMvc.perform(post("/libraryKendra/registration/userRegistration")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(userRegistration)))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
    }

    @Test
    void TestUserDetailByUsername() throws Exception{
        when(userRegistrationService.getUser(userRegistration.getUsername())).thenReturn(userRegistration);
        mockMvc.perform(MockMvcRequestBuilders.get("/libraryKendra/registration/getuser/test@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON).content(asJsonString(userRegistration)))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
        verify(userRegistrationService).getUser(userRegistration.getUsername());
        verify(userRegistrationService, times(1)).getUser(userRegistration.getUsername());
    }

    @Test
    void TestUpdateUserByUsername() throws Exception{
        when(userRegistrationService.updateUser(any(),any())).thenReturn(userRegistration);
        mockMvc.perform(MockMvcRequestBuilders.put("/libraryKendra/registration/userUpdate/test@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON).content(asJsonString(userRegistration)))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
        verify(userRegistrationService).updateUser(any(),any());
        verify(userRegistrationService, times(1)).updateUser(any(),any());
    }
    @Test
    void TestDeleteUserByUsername() throws Exception{
        when(userRegistrationService.deleteUser(userRegistration.getUsername())).thenReturn("User Deleted");
        mockMvc.perform(MockMvcRequestBuilders.delete("/libraryKendra/registration/userDelete/test@gmail.com")
                        .contentType(MediaType.APPLICATION_JSON).content(asJsonString(userRegistration)))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
        verify(userRegistrationService).deleteUser(userRegistration.getUsername());
        verify(userRegistrationService, times(1)).deleteUser(userRegistration.getUsername());
    }


    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }



}