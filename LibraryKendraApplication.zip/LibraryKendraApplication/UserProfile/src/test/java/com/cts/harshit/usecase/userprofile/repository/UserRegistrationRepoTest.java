package com.cts.harshit.usecase.userprofile.repository;

import com.cts.harshit.usecase.userprofile.model.UserRegistration;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import static org.junit.jupiter.api.Assertions.assertEquals;



@SpringBootTest
public class UserRegistrationRepoTest {

    @Autowired
    private UserRegistrationRepo userRegistrationRepo;

    private UserRegistration userRegistration;

    @BeforeEach
    public void setUp() {
        userRegistration = new UserRegistration();
        userRegistration.setUsername("test@gmail.com");
        userRegistration.setFirstname("firsttest");
        userRegistration.setLastname("lasttest");
        userRegistration.setContactnumber(879913409);
        userRegistration.setPassword("testPassword");
    }

    @AfterEach
    public void tearDown() {
        userRegistrationRepo.deleteAll();
        userRegistration = null;
    }

    @Test
    public void givenUserToSaveThenReturnSavedUser() {
        userRegistrationRepo.save(userRegistration);
        UserRegistration userRegistration1 = userRegistrationRepo.findByEmail(userRegistration.getUsername());
        assertEquals("test@gmail.com", userRegistration1.getUsername());

    }


}
