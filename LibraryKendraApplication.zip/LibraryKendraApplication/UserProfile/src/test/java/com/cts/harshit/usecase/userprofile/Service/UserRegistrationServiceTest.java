package com.cts.harshit.usecase.userprofile.Service;

import com.cts.harshit.usecase.userprofile.exception.EmailNotBlankException;
import com.cts.harshit.usecase.userprofile.exception.UserAlredayExistsException;
import com.cts.harshit.usecase.userprofile.model.UserRegistration;
import com.cts.harshit.usecase.userprofile.repository.UserRegistrationRepo;
import com.cts.harshit.usecase.userprofile.service.UserRegistrationServiceImpl;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.admin.UserScramCredentialUpsertion;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.core.KafkaTemplate;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class UserRegistrationServiceTest {

       @Mock
       private UserRegistrationRepo userRegistrationRepo;

        @Mock
        private KafkaTemplate<String,UserRegistration> kafkaTemplate;
        @Mock
        private NewTopic topic;


    private Optional optional;

    @InjectMocks
    private UserRegistrationServiceImpl userRegistrationService;


    private UserRegistration userRegistration;

    @BeforeEach
    void setUp() {
        userRegistration = new UserRegistration(123, "test@gmail.com", "firstTest", "lastTest", 879913409, "testPassword");
        optional= Optional.of(userRegistration);
    }

    @AfterEach
    void tearDown() {
        userRegistration = null;
    }

    @Test
    public void givenUserRegistrationObject_whenSave_thenReturnSavedUserRegistration() throws UserAlredayExistsException, EmailNotBlankException {
        when(userRegistrationRepo.save(eq(userRegistration))).thenReturn(userRegistration);
        assertEquals(userRegistration, userRegistrationService.saveUser(userRegistration));
        verify(userRegistrationRepo,times(1)).save(userRegistration);
    }

//    @Test
//    public void givenUserRegistrationObject_whenSave_thenReturnSavedUserRegistrationWithEmail()  {
//        assertThrows(UserAlredayExistsException.class,()->userRegistrationService.saveUser(userRegistration));
//    }

    @Test
    public void givenUserDetails_whenFindByEmail_thenReturnUserRegistration() {
        when(userRegistrationRepo.findByEmail(userRegistration.getUsername())).thenReturn(userRegistration);
        assertEquals(userRegistration, userRegistrationService.getUser(userRegistration.getUsername()));
        verify(userRegistrationRepo,times(1)).findByEmail(userRegistration.getUsername());
    }

    @Test
    public void givenUserDetails_whenUpdateUser_thenReturnUpdatedUser() {
        when(userRegistrationRepo.findByEmail(userRegistration.getUsername())).thenReturn(userRegistration);
        when(userRegistrationRepo.save(userRegistration)).thenReturn(userRegistration);
        userRegistration.setFirstname("updatedFirstName");
        UserRegistration updatedUser = userRegistrationService.updateUser(userRegistration, userRegistration.getUsername());
        assertEquals(updatedUser.getFirstname(), "updatedFirstName");
        verify(userRegistrationRepo,times(1)).save(userRegistration);
        verify(userRegistrationRepo,times(1)).findByEmail(userRegistration.getUsername());


    }

    @Test
    public void givenUserDetails_whenDeleteUser_thenReturnDeletedUser() {
        when(userRegistrationRepo.findByEmail(userRegistration.getUsername())).thenReturn(userRegistration);
        String deletedUser = userRegistrationService.deleteUser("test@gmail.com");
        assertEquals(deletedUser, "User Deleted");
        verify(userRegistrationRepo,times(1)).findByEmail(userRegistration.getUsername());
    }





}