package com.cts.harshit.usecase.gateway.librarykendragateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryKendraGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
