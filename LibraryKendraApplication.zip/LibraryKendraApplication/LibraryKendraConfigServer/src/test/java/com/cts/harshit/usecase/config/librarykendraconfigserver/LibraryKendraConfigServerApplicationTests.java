package com.cts.harshit.usecase.config.librarykendraconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryKendraConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
