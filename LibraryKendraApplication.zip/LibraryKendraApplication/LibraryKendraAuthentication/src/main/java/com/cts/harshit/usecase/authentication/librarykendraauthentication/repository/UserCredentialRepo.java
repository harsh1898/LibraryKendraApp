package com.cts.harshit.usecase.authentication.librarykendraauthentication.repository;


import com.cts.harshit.usecase.authentication.librarykendraauthentication.model.UserCredential;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface UserCredentialRepo extends JpaRepository<UserCredential,String> {

    @Query("select u from UserCredential u where u.username = :username and u.password = :password")
    UserCredential findByMailId(String username, String password);


}
