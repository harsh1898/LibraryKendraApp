package com.cts.harshit.usecase.authentication.librarykendraauthentication.model;




import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;


@Entity
@Table(name="UserCredential")
public class UserCredential {

	@Id
	@NotNull
	@Email
	private String username;

	@NotNull(message="Password can not be null")
	private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public UserCredential(String username, String password) {
		this.username = username;
		this.password = password;
//		this.registrationId = registrationId;
	}

	public UserCredential() {

	}
}
