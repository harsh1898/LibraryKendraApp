package com.cts.harshit.usecase.authentication.librarykendraauthentication.service;


import com.cts.harshit.usecase.authentication.librarykendraauthentication.exception.UserLoginNotFoundException;
import com.cts.harshit.usecase.authentication.librarykendraauthentication.model.UserCredential;
import com.cts.harshit.usecase.authentication.librarykendraauthentication.repository.UserCredentialRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserCredentialServiceImpl implements UserCredentialService{


    @Autowired
    UserCredentialRepo userCredentialRepo;

    @Override
    public boolean validateUser(UserCredential userCredential) {
    UserCredential user=userCredentialRepo.findByMailId(userCredential.getUsername(), userCredential.getPassword());
    if(user == null){
        return false;
    }
    else {
        return true;
    }
}


}
