package com.cts.harshit.usecase.authentication.librarykendraauthentication.exception;

public class UserLoginNotFoundException extends RuntimeException{

    public  UserLoginNotFoundException(String message){
        super(message);
    }
}
