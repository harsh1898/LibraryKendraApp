package com.cts.harshit.usecase.authentication.librarykendraauthentication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class LibraryKendraAuthenticationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryKendraAuthenticationApplication.class, args);
	}

}
