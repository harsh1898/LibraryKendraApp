package com.cts.harshit.usecase.authentication.librarykendraauthentication.kafka;

import com.cts.harshit.usecase.authentication.librarykendraauthentication.model.UserCredential;
import com.cts.harshit.usecase.authentication.librarykendraauthentication.repository.UserCredentialRepo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class KafkaAAuthenticationListener {


    @Autowired
    private UserCredentialRepo userCredentialRepo;


    private UserCredential userCredential;



    public KafkaAAuthenticationListener(UserCredentialRepo userCredentialRepo) {
           this.userCredentialRepo=userCredentialRepo;
           this.userCredential = new UserCredential();

       }

    private static final Logger logger = LoggerFactory.getLogger(KafkaAAuthenticationListener.class);

    @KafkaListener(topics = "${spring.kafka.topic.name}", groupId = "${spring.kafka.consumer.group-id}")
    public void consume(String value) throws JsonProcessingException {
        System.out.print(value);
        ObjectMapper objectMapper = new ObjectMapper();
        Map<String, String> responseMap = objectMapper.readValue(value, Map.class);

            userCredential.setUsername(responseMap.get("username"));
            userCredential.setPassword(responseMap.get("password"));


        userCredentialRepo.save(userCredential);
        System.out.println(responseMap);




    }





}
