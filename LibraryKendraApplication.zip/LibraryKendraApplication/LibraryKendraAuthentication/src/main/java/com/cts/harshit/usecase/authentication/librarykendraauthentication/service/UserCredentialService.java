package com.cts.harshit.usecase.authentication.librarykendraauthentication.service;

import com.cts.harshit.usecase.authentication.librarykendraauthentication.model.UserCredential;

public interface UserCredentialService {

    boolean validateUser(UserCredential userCredential);
}
