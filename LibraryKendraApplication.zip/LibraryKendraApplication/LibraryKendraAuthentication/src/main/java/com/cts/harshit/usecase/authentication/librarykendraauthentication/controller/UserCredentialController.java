package com.cts.harshit.usecase.authentication.librarykendraauthentication.controller;


import com.cts.harshit.usecase.authentication.librarykendraauthentication.exception.UserLoginNotFoundException;
import com.cts.harshit.usecase.authentication.librarykendraauthentication.model.UserCredential;
import com.cts.harshit.usecase.authentication.librarykendraauthentication.service.UserCredentialService;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@RequestMapping("libraryKendra")
@CrossOrigin(origins = "*")
public class UserCredentialController {

    @Autowired
    UserCredentialService userCredentialService;
    Logger logger = Logger.getLogger(UserCredentialController.class.getName());

    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody UserCredential userCredential)  {
        boolean result = userCredentialService.validateUser(userCredential);
        if(result){

            Map<String, String> tokenMap = new HashMap<>();
            tokenMap = generateToken(userCredential);

            logger.log(Level.INFO,"New Login Created "+tokenMap);
            return  new ResponseEntity<>(tokenMap,HttpStatus.OK);
        }
        else{
            return new ResponseEntity<String>("Invalid Credentails", HttpStatus.UNAUTHORIZED);
        }
    }
    private Map<String,String> generateToken(UserCredential profile){
        Map<String,String> jmap=new HashMap<>();
        Map<String,Object> cred=new HashMap<>();
        cred.put("username",profile.getUsername());
        cred.put("password",profile.getPassword());
        String token = Jwts.builder().setSubject(profile.getUsername())
                .setClaims(cred)
                .setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis()+ 2000000))
                .signWith(SignatureAlgorithm.HS256,"secret").compact();
        jmap.put("token",token);
        return jmap;
    }
}
