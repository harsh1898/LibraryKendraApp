package com.cts.harshit.usecase.authentication.librarykendraauthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryKendraAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
