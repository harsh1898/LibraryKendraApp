package com.cts.harshit.usecase.authentication.librarykendraauthentication.service;

import com.cts.harshit.usecase.authentication.librarykendraauthentication.model.UserCredential;
import com.cts.harshit.usecase.authentication.librarykendraauthentication.repository.UserCredentialRepo;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
class UserCredentialServiceTest {

    @Mock
    UserCredentialRepo userCredentialRepo;

    @InjectMocks
    UserCredentialServiceImpl userCredentialService;

    private UserCredential userCredential;

    @BeforeEach
    void setUp() {
        userCredential = new UserCredential("harshit@gmail.com","harshit123");

    }
    @AfterEach
    void tearDown() {
        userCredential = null;
    }

    @Test
    void testSaveUserCredential() {
        when(userCredentialRepo.findByMailId(userCredential.getUsername(), userCredential.getPassword())).thenReturn(userCredential);
        assertEquals(true, userCredentialService.validateUser(userCredential));
        verify(userCredentialRepo,times(1)).findByMailId(userCredential.getUsername(), userCredential.getPassword());
    }

}