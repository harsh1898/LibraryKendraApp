package com.cts.harshit.usecase.authentication.librarykendraauthentication.repository;

import com.cts.harshit.usecase.authentication.librarykendraauthentication.model.UserCredential;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class UserCredentialRepoTest {

    @Autowired
    UserCredentialRepo userCredentialRepo;

    private UserCredential userCredential;

    @BeforeEach
    public void setUp() {
        userCredential = new UserCredential();
        userCredential.setUsername("harshit@gmail.com");
        userCredential.setPassword("harshit123");
    }
    @AfterEach
    public void tearDown() {
        userCredentialRepo.deleteAll();
        userCredential = null;
    }
    @Test
    void testSaveUserCredential() {
        userCredentialRepo.save(userCredential);
        UserCredential savedUserCredential = userCredentialRepo.findByMailId(userCredential.getUsername(), userCredential.getPassword());
        assertEquals("harshit@gmail.com", savedUserCredential.getUsername());
        assertEquals("harshit123", savedUserCredential.getPassword());
    }


}