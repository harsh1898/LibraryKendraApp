package com.cts.harshit.usecase.authentication.librarykendraauthentication.controller;

import static org.junit.jupiter.api.Assertions.*;

class UserCredentialControllerTest {

}