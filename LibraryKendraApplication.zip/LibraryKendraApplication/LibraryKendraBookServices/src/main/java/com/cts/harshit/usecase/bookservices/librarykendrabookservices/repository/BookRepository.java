package com.cts.harshit.usecase.bookservices.librarykendrabookservices.repository;

import com.cts.harshit.usecase.bookservices.librarykendrabookservices.model.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookRepository extends JpaRepository<Book,Integer> {
}
