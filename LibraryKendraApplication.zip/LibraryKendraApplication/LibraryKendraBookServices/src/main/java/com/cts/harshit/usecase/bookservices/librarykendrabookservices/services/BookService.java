package com.cts.harshit.usecase.bookservices.librarykendrabookservices.services;

import com.cts.harshit.usecase.bookservices.librarykendrabookservices.model.Book;

import java.io.IOException;
import java.util.List;
import java.util.Map;

public interface BookService {

     List<Map<String, Object>> getAllBookDetails() throws IOException, InterruptedException;
}
