package com.cts.harshit.usecase.bookservices.librarykendrabookservices.config;

import com.cts.harshit.usecase.bookservices.librarykendrabookservices.filter.BookServiceTokenFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JwtConfig {
    @Bean
    public FilterRegistrationBean getBean(){
        FilterRegistrationBean bean = new FilterRegistrationBean();
        bean.setFilter(new BookServiceTokenFilter());
        bean.addUrlPatterns("/books/*");
        return bean;
    }
}
