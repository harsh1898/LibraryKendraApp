package com.cts.harshit.usecase.bookservices.librarykendrabookservices.services;


import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;




@Service
public class BookServiceImpl implements BookService{
    private static final String API_KEY = "1cbe0da4bcmsh48f4b2da8225a48p12a65djsn657157e05327";
    private static final String API_URL = "https://book-finder1.p.rapidapi.com/api/search?book_type=Fiction";

    @Override
    public List<Map<String, Object>> getAllBookDetails() throws IOException, InterruptedException {
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(API_URL))
                .header("X-RapidAPI-Key", API_KEY)
                .header("X-RapidAPI-Host", "book-finder1.p.rapidapi.com")
                .method("GET", HttpRequest.BodyPublishers.noBody())
                .build();
        HttpResponse<String> response = HttpClient.newHttpClient().send(request,  HttpResponse.BodyHandlers.ofString());
        String responseBody = response.body();
        ObjectMapper objectMapper = new ObjectMapper();

        Map<String, Object> responseMap = objectMapper.readValue(responseBody, Map.class);
        for (Map.Entry<String, Object> entry : responseMap.entrySet()) {
            if (entry.getKey().equals("results") && entry.getValue() instanceof List) {
                List<Map<String, String>> resultList = (List<Map<String, String>>) entry.getValue();

                List<Map<String, Object>> booksDetails = resultList.stream()
                        .map(result -> {
                            Map<String, Object> bookMap = new HashMap<>();
                            bookMap.put("work_id", result.get("work_id"));
                            bookMap.put("title", result.get("title"));
                            Object authorsObj = result.get("authors");
                            if (authorsObj instanceof List) {
                                List<String> authorsList = (List<String>) authorsObj;
                                if (!authorsList.isEmpty()) {
                                    bookMap.put("authors", authorsList.get(0));
                                }
                            }
                            bookMap.put("book_type", result.get("book_type"));
                            bookMap.put("language", result.get("language"));
                            bookMap.put("summary", result.get("summary"));
                            Object publishedWorksObj = result.get("published_works");
                            if (publishedWorksObj instanceof List) {
                                List<Map<String, Object>> publishedWorksList = (List<Map<String, Object>>) publishedWorksObj;
                                if (!publishedWorksList.isEmpty()) {
                                    Map<String, Object> firstPublishedWork = publishedWorksList.get(0);
                                    bookMap.put("cover_art_url", firstPublishedWork.get("cover_art_url"));
                                } else {
                                    bookMap.put("cover_art_url", "");
                                }
                            }
                            return bookMap;
                        })
                        .collect(Collectors.toList());
                return booksDetails;

            }
        }
        return null;

    }
}
