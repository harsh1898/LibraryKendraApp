package com.cts.harshit.usecase.bookservices.librarykendrabookservices.controller;

import com.cts.harshit.usecase.bookservices.librarykendrabookservices.exception.BookNotFoundException;
import com.cts.harshit.usecase.bookservices.librarykendrabookservices.services.BookService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/books")
@CrossOrigin(origins = "*")
@SecurityRequirement(name = "bearerAuth")
//@CircuitBreaker(name="LibraryKendraBookService",fallbackMethod = "bookServiceFail")
public class BookController {

    private final BookService bookService;

    @Autowired
    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("/getbook")
    public ResponseEntity<?> getBook() throws IOException, InterruptedException,BookNotFoundException {
        try {

                return ResponseEntity.ok(bookService.getAllBookDetails());


        }catch(BookNotFoundException e){
            return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
        }


    }
//    public ResponseEntity<String> bookServiceFail(Exception exception){
//        return new ResponseEntity<String>("Service is down.. Wait for some time ",HttpStatus.OK);
//    }
}
