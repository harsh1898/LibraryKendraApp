package com.cts.harshit.usecase.bookservices.librarykendrabookservices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryKendraBookServicesApplicationTests {

    @Test
    void contextLoads() {
    }

}
