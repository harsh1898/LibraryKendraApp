package com.cts.harshit.usecase.eurekaserver.librarykendraeurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryKendraEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
