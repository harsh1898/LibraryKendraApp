package com.cts.harshit.usecase.eurekaserver.librarykendraeurekaserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class LibraryKendraEurekaServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryKendraEurekaServerApplication.class, args);
	}

}
