import React from 'react';
import { render, screen } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import Landing from './Landing/Landing';

test('test welcome text when Landing page rendering',()=>{
    render(
        <MemoryRouter>
        <Landing/>
        </MemoryRouter>
    ),
    expect(screen.getByText(/Take your stories wherever you go/i)).toBeInTheDocument();
})

test('test welcome Images when Landing page rendering',()=>{
    render(
        <MemoryRouter>
            <Landing/>
        </MemoryRouter>
    ),
    expect(screen.getByTestId('webImg')).toBeInTheDocument();
})
test('test Hero content heading when Landing page rendering',()=>{
    render(
        <MemoryRouter>
            <Landing/>
        </MemoryRouter>
    ),
    expect(screen.getByText(/Browse Our Collections/i)).toBeInTheDocument();
})