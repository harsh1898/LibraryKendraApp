import React from "react";
import Login from './Login/Login';
import { render, screen,fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

test("render Login Now Text when Login render",()=>{
    render(<MemoryRouter><Login/></MemoryRouter>);

    expect(screen.getByText(/Login Now/i)).toBeInTheDocument();

});

test("Login renders Form, accepts email and change state value",()=>{
    render(<MemoryRouter><Login/></MemoryRouter>);
    const inputElement = screen.getByTestId('emailInput');
    fireEvent.change(inputElement, { target: { value: 'dummy@gmail.com' } });
    
    expect(inputElement).toBeInTheDocument();

});

test("Login renders Form, accepts password and change state value",()=>{
    render(<MemoryRouter><Login/></MemoryRouter>);
    const inputElement = screen.getByTestId('passwordInput');
    fireEvent.change(inputElement, { target: { value: 'NewName' } });
    
    expect(inputElement).toBeInTheDocument();

});

test("Login renders Form, test login button",()=>{
    render(<MemoryRouter><Login/></MemoryRouter>);
    const buttonElement = screen.getByTestId('testButton');
    fireEvent.click(buttonElement, { target: { value: 'NewName' } });
    
    expect(buttonElement).toBeInTheDocument();

});

