import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import Nav from "../Navbar/Nav";
import Footer from "../Footer/Footer";
import "./BookDetail.css";
import axios from "axios";
import { MdOutlineFavorite } from "react-icons/md";

const Bookdetail = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { state } = location;
  const hasEffectRun = useRef(false);
  const [particularbook, setParticularbook] = useState({});
  const authuser = sessionStorage.getItem("token");
  const getUsername = sessionStorage.getItem("username");
  useEffect(() => {
    if (!hasEffectRun.current && state && state.bookData) {
      setParticularbook(state.bookData);
      setParticularbook((prevBook) => ({
        ...prevBook,
        username: getUsername,
      }));
      hasEffectRun.current = true;
    }
  }, [state,getUsername]);
  const handleClick = async (e) => {
    e.preventDefault();
    await axios
      .post("http://44.218.65.97:8084/wishlist/addWishlist", particularbook, {
        headers: { Authorization: `Bearer ${authuser}` },
      })
      .then((response) => {
        alert("Successfully Added to Wishlist")
        navigate("/wishlist");
      })
      .catch((error) => {
        if (error.response && error.response.status === 500) {
          sessionStorage.clear();
          navigate("/login");
        }else {
          alert(error.response.data);
        }
      });
  };
  return (
    <>
      <Nav />
      <div
        className="card mb-3 book-items"
        key={particularbook.work_id}
        style={{ maxWidth: "50rem" }}
      >
        <div className="row g-0">
          <div className="col-md-4">
            <img
              src={particularbook.cover_art_url}
              className="img-fluid rounded-start"
              alt="..."
            />
          </div>
          <div className="col-md-8 bookdetailBody">
            <div className="card-body ">
              <h4 className="card-title title">
                <span className="bookDetailTitlename">{particularbook.title}</span>
              </h4>
              <p className="card-text">
                <h5 key={particularbook.authors}>
                  Author: {particularbook.authors}
                </h5>
                <p key={particularbook.language}>
                  Available in {particularbook.language}
                </p>
                <span>
                {particularbook.summary}
                </span>
                <br />
                <h4 className="wishlist-head">
                 <span> Add to Wishlist</span> 
                  <MdOutlineFavorite
                    className="whishIcon" 
                    onClick={(e) => handleClick(e)}
                  />
                </h4>
              </p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
};

export default Bookdetail;
