import { useEffect, useState } from "react";
import axios from "axios";
import "./Book.css";
import Nav from "../Navbar/Nav";
import Footer from "../Footer/Footer";
import { Link, useNavigate } from "react-router-dom";
import { BiSearch } from "react-icons/bi";

const Book = () => {
  const [allbook, setAllbook] = useState([]);
  const [filteredBooks, setFilteredBooks] = useState([]);
  const authuser = sessionStorage.getItem("token");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(9);
  const navigate = useNavigate();
  useEffect(() => {
    getAllBooks();
    window.addEventListener("popstate", (e) => {
      window.history.go(1);
    });
  }, []);

  const getAllBooks = async () => {
    await axios
      .get("http://44.218.65.97:8083/books/getbook", {
        headers: { Authorization: `Bearer ${authuser}` },
      })
      .then((response) => {
        setAllbook(response.data);
        setFilteredBooks(response.data);
        navigate("/book");
      })
      .catch((error) => {
        if (error.response && error.response.status === 500) {
          sessionStorage.clear();
          navigate("/login");
        }
      });
  };
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = filteredBooks.slice(indexOfFirstItem, indexOfLastItem);

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  const handleSearch = (e) => {
    const searchQuery = e.target.value.toLowerCase();
    const filtered = allbook.filter((book) =>
      book.title.toLowerCase().includes(searchQuery)
    );
    if (filtered.length === 0) {
      alert("Please search with correct Book Name");
    }else{
    setFilteredBooks(filtered);
    setCurrentPage(1);
    }
  };
  return (
    <>
      <Nav />

      {authuser !== null ? (
        <>
          <nav className="navbar navbar-expand-lg" data-testid="testBook">
            <div className="container-fluid search-conatiner">
              <input
                className="form-control me-2 bookSearch"
                type="search"
                placeholder="Search Book"
                onChange={(e) => handleSearch(e)}
                aria-label="Search"
              />
              <span className="input-group-text serach-icon" id="basic-addon2">
                <BiSearch />
              </span>
            </div>
          </nav>
          {currentItems.length !== 0 ? (
            <>
              {Array.isArray(currentItems) &&
                currentItems
                  .map((book, index) => (
                    <div className="card-group bookCard-conatiner">
                      <div className="card bcard">
                        <img
                          src={book.cover_art_url}
                          class="card-img-top bookimg"
                          alt="..."
                        />
                        <div className="card-body bookCardBody">
                          <h5 className="card-title">{book.title}</h5>
                          <p className="card-text">{book.authors}</p>
                          <Link
                            className="details"
                            to={`/bookDetails/id/${book.work_id}`}
                            state={{ bookData: book }}
                            key={book.work_id}
                          >
                            Read More..
                          </Link>
                        </div>
                      </div>
                    </div>
                  ))
                  .reduce((rows, card, index) => {
                    if (index % 3 === 0) {
                      rows.push([card]);
                    } else {
                      rows[rows.length - 1].push(card);
                    }
                    return rows;
                  }, [])
                  .map((row, rowIndex) => (
                    <div className="row mb-3 threeCards" key={rowIndex}>
                      {row.map((card, cardIndex) => (
                        <div className="col-md-4" key={cardIndex}>
                          {card}
                        </div>
                      ))}
                    </div>
                  ))}
            </>
          ) : (
            <div
              class="card"
              aria-hidden="true"
              style={{ width: "50%", margin: "auto" }}
            >
              <img src="..." class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title placeholder-glow">
                  <span class="placeholder col-6"></span>
                </h5>
                <p class="card-text placeholder-glow">
                  <span class="placeholder col-7"></span>
                  <span class="placeholder col-4"></span>
                  <span class="placeholder col-4"></span>
                  <span class="placeholder col-6"></span>
                  <span class="placeholder col-8"></span>
                </p>
                <a
                  class="btn btn-primary disabled placeholder col-6"
                  aria-disabled="true"
                ></a>
              </div>
            </div>
           
          )}

          <div className="pagination">
            {Array.from({
              length: Math.ceil(filteredBooks.length / itemsPerPage),
            }).map((_, index) => (
              <button key={index} onClick={() => paginate(index + 1)}>
                {index + 1}
              </button>
            ))}
          </div>
        </>
      ) : (
        <h1>Can't Access Directly, Login First</h1>
      )}

      <Footer />
    </>
  );
};

export default Book;
