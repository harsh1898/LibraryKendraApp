import React, { useState } from "react";
import "./registration.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import Nav from "../Navbar/Nav";
import Footer from "../Footer/Footer";

const RegisterDetail = () => {
  const navigate = useNavigate();
  const [username, setUsername] = useState("");
  const [firstname, setFirstName] = useState("");
  const [lastname, setLastName] = useState("");
  const [contact, setContact] = useState(0);
  const [password, setPassword] = useState("");
  const submitDetails = async (e) => {
    e.preventDefault();
    const userData = {
      username: username,
      firstname: firstname,
      lastname: lastname,
      contactnumber: contact,
      password: password,
    };

    await axios
      .post(
        "http://44.218.65.97:8082/libraryKendra/registration/userRegistration",
        userData
      )
      .then((response) => {
        setUsername("");
        setFirstName("");
        setLastName("");
        setContact(0);
        setPassword("");
        alert("User registered Successfully");

        navigate("/login");
      })
      .catch((error) => {
        alert(error.response.data);
      });
  };
  return (
    <>
      <Nav />
      <div className="row register-conatiner g-0">
        <div className="col-sm-6">
          <div className="card">
            <div className="card-body left-part">
              <h4 className="card-title card-heading">
                Register now and join our community!!
              </h4>
              <p className="card-text">
                <img className="side-img" src="../logo.png" alt="" />
              </p>
            </div>
          </div>
        </div>
        <div className="col-sm-6">
          <div className="card">
            <div className="card-body right-part">
              <p className="card-text">
                <form className="form-container">
                  <input
                    type="text"
                    className="inputBox"
                    placeholder="enter username as a email"
                    value={username}
                    onChange={(event) => setUsername(event.target.value)}
                    data-testid="registerEmailInput"
                    required
                  />

                  <input
                    type="text"
                    className="inputBox"
                    placeholder="enter your first name"
                    value={firstname}
                    onChange={(event) => setFirstName(event.target.value)}
                    data-testid="fnameInput"
                    required
                  />

                  <input
                    type="text"
                    className="inputBox"
                    placeholder="enter your last name"
                    value={lastname}
                    data-testid="lname"
                    onChange={(event) => setLastName(event.target.value)}
                    required
                  />

                  <input
                    type="number"
                    className="inputBox"
                    placeholder="enter your contact number"
                    value={contact}
                    onChange={(event) => setContact(event.target.value)}
                    data-testid="phno"
                    required
                  />

                  <input
                    type="password"
                    className="inputBox"
                    placeholder="create password"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    data-testid="testPassword"
                    required
                  />
                  <input
                    type="submit"
                    className="registerSubmit"
                    value="Register"
                    data-testid="testRegister"
                    onClick={submitDetails}
                  />
                </form>
              </p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default RegisterDetail;
