import { Link, useNavigate } from "react-router-dom";
import "./Navbar.css";
import { AiOutlineLogout } from "react-icons/ai";
import { FaBook } from "react-icons/fa";
import { IoMdHome } from "react-icons/io";
import { BiTask } from "react-icons/bi";
import { MdFavorite } from "react-icons/md";
import { MdAccountBox } from "react-icons/md";

const Nav = ({ count }) => {
  const authuser = sessionStorage.getItem("token");
  const username = sessionStorage.getItem("username");
  const navigate = useNavigate();
  const handlelogOut = (e) => {
    e.preventDefault();
    sessionStorage.clear();
    navigate("/");
  };
  return (
    <nav className="navbar navbar-expand-lg mynav" data-testid="testNavbar">
      <div className="container-fluid fluidnav">
        <button
          className="navbar-toggler btn btn-danger collapseIcon"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarTogglerDemo01"
          aria-controls="navbarTogglerDemo01"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon collapseIcon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarTogglerDemo01">
          <FaBook className="brandName" />
          <span className="brandName">LibraryKendra</span>

          {authuser != null ? (
            <ul className="navbar-nav me-auto mb-2 mb-lg-0 navList">
              <li className="nav-item">
                <Link className="nav-link" aria-current="page" to="/book">
                  <IoMdHome style={{ color: "blue" }} /> Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/wishlist">
                  <MdFavorite style={{ color: "blue" }} position-relative />{" "}
                  Wishlist
                  <span class="badge text-bg-secondary">{count}</span>
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" to="/profile">
                  <MdAccountBox style={{ color: "blue" }} /> Profile
                </Link>
              </li>
            </ul>
          ) : (
            <ul className="navbar-nav me-auto mb-2 mb-lg-0 home">
              <li className="nav-item">
                <Link className="nav-link " aria-current="page" to="/">
                  <IoMdHome style={{ color: "blue" }} /> Home
                </Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link" aria-current="page" to="/services">
                  <BiTask style={{ color: "blue" }} /> Services
                </Link>
              </li>
            </ul>
          )}
          {authuser != null ? (
            <span className="navbar-text">
              <span className="welcomeUser">Hello, {username}</span>

              <AiOutlineLogout
                className="logOut"
                onClick={handlelogOut}
                data-testid="logoutbutton"
              />
            </span>
          ) : (
            <div className="d-flex" role="search">
              <Link className="nav-link login" to="/login">
                Login
              </Link>
              <Link className="nav-link signup" to="/registration">
                Sign Up
              </Link>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Nav;
