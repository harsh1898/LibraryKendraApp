import { useEffect, useState } from "react";
import axios from "axios";
import Nav from "../Navbar/Nav";
import Footer from "../Footer/Footer";
import "./Wishlist.css";
import { MdDeleteForever } from "react-icons/md";
import { FaCartShopping } from "react-icons/fa6";
import { TfiFaceSad } from "react-icons/tfi";

const Wishlist = () => {
  const gettoken = sessionStorage.getItem("token");
  const getUsername = sessionStorage.getItem("username");
  const [wishlistdata, setWishlistdata] = useState([]);
  useEffect(() => {
    getWishlist();
  }, []);

  const getWishlist = async () => {
    await axios
      .get(`http://44.218.65.97:8084/wishlist/getWishlist/${getUsername}`, {
        headers: { Authorization: `Bearer ${gettoken}` },
      })
      .then((response) => {
       
        setWishlistdata(response.data);
      
      })
      .catch((error) => {
        if (error.response && error.response.status === 500) {
          sessionStorage.clear();
          window.location.href = "Login";
        }else{
          console.log(error.response);
        }
      });
  };

  const handleDeleteWishlist = (workId) => {
    axios
      .delete(`http://44.218.65.97:8084/wishlist/deleteWishlist/${workId}`, {
        headers: { Authorization: `Bearer ${gettoken}` },
      })
      .then((response) => {
        const removeId = workId;
        const filterData = wishlistdata.filter(
          (item) => item.work_id !== removeId
        );
        setWishlistdata(filterData);
        console.log("After filter", wishlistdata);
      })
      .catch((error) => {
        if (error.response && error.response.status === 500) {
          sessionStorage.clear();
          window.location.href = "/login";
        } else {
          alert(error.response);
        }
      });
  };
  return (
    <>
      <Nav count={wishlistdata.length} />
      {wishlistdata.length !== 0 ? (
        <>
          <h3 className="wishlist-head">
            Wishlist Cart <FaCartShopping className="cartIcon" />
          </h3>
          {Array.isArray(wishlistdata) &&
            wishlistdata.map((book) => (
              <div
                className="card mb-3 book-items"
                key={book.work_id}
                style={{ maxWidth: "50rem" }}
              >
                <div className="row g-0">
                  <div className="col-md-4">
                    <img
                      src={book.cover_art_url}
                      className="img-fluid rounded-start bookimg"
                      alt="..."
                    />
                  </div>
                  <div className="col-md-8">
                    <div className="card-body">
                      <h4 className="card-title title">
                        Title :<span className="titlename">{book.title}</span>
                      </h4>
                      <p className="card-text">
                        <h5 key="">Author: {book.authors}</h5>
                        {book.summary}
                        <br />

                        <MdDeleteForever
                          className="deleteIcon"
                          onClick={() => handleDeleteWishlist(book.work_id)}
                        />
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </>
      ) : (
        <div class="card text-center empty-container">
          <div class="card-header emptyHeader">
            <TfiFaceSad className="emptyIcon" />
          </div>
          <div class="card-body emptyBody">
            <h5 class="card-title emptyContent">Wishlist Empty!!</h5>
          </div>
        </div>
      )}
      <Footer />
    </>
  );
};

export default Wishlist;
