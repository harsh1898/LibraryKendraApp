import "./Profile.css";
import Nav from "../Navbar/Nav";
import Footer from "../Footer/Footer";
import ProfileImg from "../images/profile.png";
import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
const Profile = () => {
  const getusername = sessionStorage.getItem("username");
  const gettoken = sessionStorage.getItem("token");
  const [userdata, setUserdata] = useState({});
  const [flagbutton, setFlagbutton] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    handleUserData();
  }, []);
  const handleUserData = async () => {
    await axios
      .get(
        `http://44.218.65.97:8082/libraryKendra/registration/getuser/${getusername}`,
        {
          headers: { Authorization: `Bearer ${gettoken}` },
        }
      )
      .then((response) => {
        setUserdata(response.data);
      })
      .catch((error) => {
        if (!gettoken) {
          sessionStorage.clear();
          navigate("/login");
        } else {
          alert(error.response);
        }
      });
  };

  const handleProfileChange = (event) => {
    setUserdata({ ...userdata, [event.target.name]: event.target.value });
  };
  const handleUpdate = () => {
    setFlagbutton(true);
  };

  const setNewData = () => {
    axios
      .put(
        `http://localhost:8085/libraryKendra/registration/userUpdate/${getusername}`,
        userdata,
        { params: { username: getusername } },
        {
          headers: { Authorization: `Bearer ${gettoken}` },
        }
      )
      .then((response) => {
        alert("Profile Successfully Updated");
      })
      .catch((error) => {
        console.log(error.response);
      });

    setFlagbutton(false);
  };

  return (
    <>
      <Nav />
      <div className="card profile-container" style={{ width: "18rem" }}>
        <img src={ProfileImg} className="card-img-top" alt="..." />
        <div className="card-body profile-body">
          {flagbutton == false ? (
            <h5 className="card-title">Profile</h5>
          ) : (
            <h5 className="card-title">Update your profile</h5>
          )}
          <p className="card-text">
            <input
              type="text"
              className="profile-name"
              value={userdata.username}
              readOnly
            />
          </p>
          <p className="card-text">
            <input
              type="text"
              className="profile-name"
              name="firstname"
              style={
                flagbutton ? { borderColor: "red" } : { borderColor: "white" }
              }
              value={userdata.firstname}
              onChange={handleProfileChange}
              readOnly={flagbutton ? "" : "readOnly"}
            />
          </p>
          <p className="card-text">
            <input
              type="text"
              className="profile-name"
              name="lastname"
              style={
                flagbutton ? { borderColor: "red" } : { borderColor: "white" }
              }
              value={userdata.lastname}
              onChange={handleProfileChange}
              readOnly={flagbutton ? "" : "readOnly"}
            />
          </p>
          <p className="card-text">
            <input
              type="text"
              className="profile-name"
              name="contactnumber"
              style={
                flagbutton ? { borderColor: "red" } : { borderColor: "white" }
              }
              value={userdata.contactnumber}
              onChange={handleProfileChange}
              readOnly={flagbutton ? "" : "readOnly"}
            />
          </p>
          {flagbutton == false ? (
            <Link to="#" className="btn btn-primary" onClick={handleUpdate}>
              Set Profile
            </Link>
          ) : (
            <Link to="#" className="btn btn-primary" onClick={setNewData}>
              Update
            </Link>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
};

export default Profile;
