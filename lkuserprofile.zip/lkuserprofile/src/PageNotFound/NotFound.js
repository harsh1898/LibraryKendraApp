import { TfiFaceSad } from "react-icons/tfi";
import './NotFound.css';
const NotFound=()=> {
    return ( 
        <h2 className="errorPage">
        404 Not Found <TfiFaceSad className="notFound"/>
        </h2>
     );
}

export default NotFound;