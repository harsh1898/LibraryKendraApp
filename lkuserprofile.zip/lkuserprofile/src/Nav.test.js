import React from "react";
import { render, screen } from "@testing-library/react";
import Nav from "./Navbar/Nav";
import { MemoryRouter, Routes, Route } from "react-router-dom";

test("render Navbar Component", () => {
  render(
    <MemoryRouter>
      <Nav />
    </MemoryRouter>
  );

  const mockNavDataElement = screen.getByTestId(/testNavbar/i);
  expect(mockNavDataElement).toBeInTheDocument();
});

test("render LibraryKendra text when Navbar component render", () => {
  render(
    <MemoryRouter>
      <Nav />
    </MemoryRouter>
  );

  const mockNavTextDataElement = screen.getByText(/LibraryKendra/i);
  expect(mockNavTextDataElement).toBeInTheDocument();
});

test("test login button when Navbar render", () => {
  render(
    <MemoryRouter>
      <Nav />
    </MemoryRouter>
  );
  const mockLoginElement = screen.getByText(/Login/i);
  expect(mockLoginElement).toBeInTheDocument();
});

test("test signup button when Navbar render", () => {
  render(
    <MemoryRouter>
      <Nav />
    </MemoryRouter>
  );
  const mockSignupElement = screen.getByText(/Sign Up/i);
  expect(mockSignupElement).toBeInTheDocument();
});

describe("Navbar Component", () => {
  test("renders logout button when user is authenticated", () => {
    sessionStorage.setItem("token", "fakeToken");
    sessionStorage.setItem("username", "testUser");

    render(
      <MemoryRouter>
        <Routes>
          <Route path="/" element={<Nav />} />
        </Routes>
      </MemoryRouter>
    );

    const logoutButton = screen.getByTestId("logoutbutton");
    expect(logoutButton).toBeInTheDocument();

    const welcomeMessage = screen.getByText("Hello, testUser");
    expect(welcomeMessage).toBeInTheDocument();
  });
});
