import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import RegisterDetail from "./Registration/RegisterDetail";

test("render Register Now Text when Register render", () => {
  render(
    <MemoryRouter>
      <RegisterDetail />
    </MemoryRouter>
  );

  expect(
    screen.getByText(/Register now and join our community/i)
  ).toBeInTheDocument();
});

test("test email input", () => {
  render(
    <MemoryRouter>
      <RegisterDetail />
    </MemoryRouter>
  );

  const emailElement = screen.getByTestId("registerEmailInput");
  fireEvent.change(emailElement, { target: { value: "dummy@gmail.com" } });

  expect(emailElement).toBeInTheDocument();
});
test("test firstName input", () => {
  render(
    <MemoryRouter>
      <RegisterDetail />
    </MemoryRouter>
  );

  const fnameElement = screen.getByTestId("fnameInput");
  fireEvent.change(fnameElement, { target: { value: "dummy" } });

  expect(fnameElement).toBeInTheDocument();
});

test("test lastName input", () => {
  render(
    <MemoryRouter>
      <RegisterDetail />
    </MemoryRouter>
  );

  const lnameElement = screen.getByTestId("lname");
  fireEvent.change(lnameElement, { target: { value: "test" } });

  expect(lnameElement).toBeInTheDocument();
});

test("test contact number input", () => {
  render(
    <MemoryRouter>
      <RegisterDetail />
    </MemoryRouter>
  );

  const phnoElement = screen.getByTestId("phno");
  fireEvent.change(phnoElement, { target: { value: 8799134095 } });

  expect(phnoElement).toBeInTheDocument();
});

test("test password input", () => {
  render(
    <MemoryRouter>
      <RegisterDetail />
    </MemoryRouter>
  );

  const passwordElement = screen.getByTestId("testPassword");
  fireEvent.change(passwordElement, { target: { value: "test" } });

  expect(passwordElement).toBeInTheDocument();
});

test("Registration renders Form, test register button", () => {
  render(
    <MemoryRouter>
      <RegisterDetail />
    </MemoryRouter>
  );
  const buttonElement = screen.getByTestId("testRegister");
  fireEvent.click(buttonElement, { target: { value: "NewName" } });

  expect(buttonElement).toBeInTheDocument();
});
