import "./App.css";
import Landing from "./Landing/Landing";
import RegisterDetail from "./Registration/RegisterDetail";
import Login from "./Login/Login";
import Book from "./Book/Book";
import BookDetail from "./BookDetail/Bookdetail";
import Wishlist from "./Wishlist/Wishlist";
import Profile from "./Profile/Profile";
import Services from "./Services/Services";
import NotFound from "./PageNotFound/NotFound";
import { BrowserRouter, Routes, Route } from "react-router-dom";
function App() {
  
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="*" element={<NotFound />} />
          <Route path="/services" element={<Services />} />
          <Route path="/registration" element={<RegisterDetail />} />
          <Route path="/login" element={<Login />} />
          <Route path="/book" element={<Book />}/>
          <Route path="/bookDetails/id/:id" element={<BookDetail /> }/>
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/profile" element={<Profile />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
