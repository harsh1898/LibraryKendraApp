import './Footer.css';

function Footer() {
    return ( 
        <nav class="navbar  footer">
          <span className='copyRight'>&copy; 2023 LibraryKendra. All rights reserved.</span>
        </nav>
     );
}

export default Footer;