import Nav from '../Navbar/Nav';
import Footer from '../Footer/Footer';
import { FaHandPointRight } from "react-icons/fa";
import './Services.css';
const Services=()=> {
    return ( 
    <>
    <Nav/>
    <div class="card serviceCard" data-testid="testServices">
  <div class="card-header">
    Our Services
  </div>
  <ul class="list-group list-group-flush">
    <li class="list-group-item points"> <FaHandPointRight className='bulletPoints' />
   <h5 className='serviceText'>Quickly Register and Login.</h5></li>
    <li class="list-group-item points"><FaHandPointRight className='bulletPoints' />
   <h5 className='serviceText'>Browse more collections with Books.</h5></li>
    <li class="list-group-item points"><FaHandPointRight className='bulletPoints' />
   <h5 className='serviceText'>Wishlist your favorite books in cart.</h5></li>
  </ul>
</div>
   
   
    <Footer/>
    </> 
    );
}

export default Services;