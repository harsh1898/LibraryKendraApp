import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";
import axios from "axios";
import Nav from "../Navbar/Nav";
import Footer from '../Footer/Footer';
const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const submitLogin = (e) => {
    e.preventDefault();
    const loginData = { username: username, password: password };
    axios
      .post("http://44.218.65.97:8086/libraryKendra/login", loginData)
      .then((response) => {
        sessionStorage.setItem("token", response.data.token);
        sessionStorage.setItem("username", username);
        alert("Login Successful");
        navigate("/book");
      })
      .catch((error) => {
        alert(error.response.data);
      });
  };
  return (
    <>
      <Nav />
      <div className="row login-conatiner g-0">
        <div className="col-sm-6">
          <div className="card">
            <div className="card-body login-left-part">
              <h4 className="card-title login-card-heading">Login Now!!</h4>
              <p className="card-text">
                <img className="login-side-img" src="../logo.png" alt="" />
              </p>
            </div>
          </div>
        </div>
        <div className="col-sm-6">
          <div className="card">
            <div className="card-body login-right-part">
              <p className="card-text">
                <form className="loginform-container">
                  <input
                    type="text"
                    className="logininputBox"
                    placeholder="enter username as a email"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    data-testid="emailInput"
                    required
                  />

                  <input
                    type="password"
                    className="logininputBox"
                    placeholder="create password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    data-testid="passwordInput"
                    required
                  />
                  <input
                    type="submit"
                    className="loginSubmit"
                    value="Login"
                    data-testid="testButton"
                    onClick={submitLogin}
                  />
                </form>
              </p>
            </div>
          </div>
        </div>
      </div>
      <Footer/>
      </>
  );
};

export default Login;
