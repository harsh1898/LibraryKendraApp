import React from 'react';
import { render, screen } from '@testing-library/react';
import { MemoryRouter, Routes, Route } from 'react-router-dom';
import Landing from './Landing/Landing'; 
import Services from "./Services/Services";

test('renders Landing component for / route', () => {
  render(
    <MemoryRouter initialEntries={['/']}>
      <Routes>
        <Route path="/" element={<Landing />} />
      </Routes>
    </MemoryRouter>
  );

  const mockDataElement = screen.getByTestId(/main/i);
  expect(mockDataElement).toBeInTheDocument();
});

test('renders Service Component for /service',()=>{
  const { getByTestId }= render(
<MemoryRouter initialEntries={['/services']}>
      <Routes>
      <Route path="/services" element={<Services />} />
      </Routes>
    </MemoryRouter>);
const mockServiceDataElement = screen.getByTestId(/testServices/i);
expect(mockServiceDataElement).toBeInTheDocument();
});
