import "./Home.css";
import Nav from "../Navbar/Nav";
import Footer from "../Footer/Footer";
import img1 from "../images/img1.PNG";
import img2 from "../images/img2.PNG";
import img3 from "../images/img3.PNG";
import img4 from "../images/img4.PNG";
import img5 from "../images/img5.PNG";
import img6 from "../images/img6.PNG";
import backImg from "../images/libraryBackground.jpg";
import demoImg from "../images/demo.PNG";
import demophone from "../images/demoPhone.PNG";
const Landing = () => {
  return (
    <div data-testid="main">
      <Nav />

      <div class="card text">
        <img src={backImg} class="card-img homeImg" alt="..." />
        <div class="card-img-overlay">
          <p class="card-text">
            <span className="brandHomeMessage">Take your stories wherever you go</span>
            <img src={demoImg} className="demoImage" alt="" data-testid="webImg"/>
            <img src={demophone} className="demoPhoneImage" alt=""/>
          </p>
        </div>
      </div>
      <section className="content-container">
        <h3 className="headContent">Browse Our Collections</h3>

        <div className="card w-75 mb-3 paraContent">
          <div className="card-body ">
            <p className="card-text">
              Each Collection of <b>LibraryKendra</b> represents a domain of
              human development wisdom that influences—or is influenced
              by—coaching. Connecting these fields of inquiry is our commitment
              to investigate how coaching contributes to the United Nations
              Action Plan for societal well-being. As a holistic system, these
              four pillars inform our research focus, which in turn generates
              our body of knowledge.
            </p>
          </div>
        </div>
      </section>
      <div
        id="carouselExampleIndicators"
        className="carousel slide slider-container"
      >
        <div class="carousel-indicators">
          <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="0"
            class="active"
            aria-current="true"
            aria-label="Slide 1"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="1"
            aria-label="Slide 2"
          ></button>
          <button
            type="button"
            data-bs-target="#carouselExampleIndicators"
            data-bs-slide-to="2"
            aria-label="Slide 3"
          ></button>
        </div>
        <div className="carousel-inner">
          <div className="carousel-item active">
            <div className="card-group sliderCard">
              <div className="card sliderCard">
                <img src={img1} class="card-img-top img-slider" alt="..." />
                <div className="card-body sliderCard">
                  <h5 className="card-title">The Winners</h5>
                  <p className="card-text">This is motivational book.</p>
                </div>
              </div>
              <div class="card sliderCard">
                <img src={img2} class="card-img-top img-slider" alt="..." />
                <div class="card-body">
                  <h5 class="card-title">The River We Remember</h5>
                  <p class="card-text">This is novel.</p>
                </div>
              </div>
              <div class="card">
                <img src={img3} class="card-img-top img-slider" alt="..." />
                <div class="card-body">
                  <h5 class="card-title">Tamarack County</h5>
                  <p class="card-text">This is novel.</p>
                </div>
              </div>
            </div>
          </div>
          <div className="carousel-item">
            <div class="card-group">
              <div class="card">
                <img src={img4} class="card-img-top img-slider" alt="..." />
                <div class="card-body">
                  <h5 class="card-title">Blood Hollow</h5>
                  <p class="card-text">This is Horror book.</p>
                </div>
              </div>
              <div class="card">
                <img src={img5} class="card-img-top img-slider" alt="..." />
                <div class="card-body">
                  <h5 class="card-title">Mercy Falls</h5>
                  <p class="card-text">This is poem.</p>
                </div>
              </div>
              <div class="card">
                <img src={img6} class="card-img-top img-slider" alt="..." />
                <div class="card-body">
                  <h5 class="card-title">War and Peace</h5>
                  <p class="card-text">This is social book.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <button
          className="carousel-control-prev"
          type="button"
          data-bs-target="#carouselExampleIndicators"
          data-bs-slide="prev"
        >
          <span
            className="carousel-control-prev-icon prevIconbutton"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button
          className="carousel-control-next"
          type="button"
          data-bs-target="#carouselExampleIndicators"
          data-bs-slide="next"
        >
          <span
            className="carousel-control-next-icon nextIconbutton"
            aria-hidden="true"
          ></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>

      <Footer />
    </div>
  );
};

export default Landing;
